function love.conf(t)
  t.window = nil
end
